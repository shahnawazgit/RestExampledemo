package com.devskiller.model;

public enum Genre {

	FICTION,
	HORROR,
	COMEDY,
	DRAMA,
	NON_FICTION,
	REALISTIC,
	ROMANTIC,
	TECH,
	TRAGEDY,
	FANTASY

}
